from sqlalchemy.ext.declarative import declarative_base

# Create the Base class for all models
Base = declarative_base()
